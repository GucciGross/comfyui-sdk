You are the implementation agent for a fresh standalone repository.

Your job is to read and execute every document in `/docs` and build the MVP package described there.

Critical rules:
- `/docs` is the source of truth
- these docs replace the older docs
- do not stop at planning
- actually build the package
- keep implementation modular, typed, and practical
- README.md is required

Important updated rule after re-review:
The public `comfy-addons/comfyui-sdk` repository may be used as inspiration or as an internal helper for the local adapter, but it must not define this repo's public API.

Core mission:
Build a standalone TypeScript bridge package for:
- ComfyUI Local
- ComfyUI Cloud
- provider mode `local`, `cloud`, `auto`
- local-preferred cloud fallback
- GUI-friendly public types for app integration

Execution order:
1. Read `docs/00-README-FIRST.md`
2. Read every remaining doc in `/docs`
3. Build the package according to the MVP build plan
4. Write README.md as a real deliverable
5. Add examples and focused tests

Mandatory behavior:
- support `local`, `cloud`, `auto`
- support local-preferred routing in `auto`
- support cloud fallback when local is unavailable and fallback is enabled
- normalize provider errors
- expose routing metadata including requested provider, actual provider used, fallback triggered, and fallback reason
- expose public config types that can power a GUI switcher

Public API must support:
- mode
- preferredLocalInstanceId
- fallbackToCloud
- retryOnConnectionFailure
- localTimeoutMs
- providerUsed
- fallbackReason

Implementation rules:
- TypeScript
- clean exports
- adapter pattern
- do not leak external SDK classes in public exports
- keep provider-specific quirks inside adapters
- prefer MVP practicality over overengineering

Definition of done:
- codebase exists and is buildable
- local adapter exists
- cloud adapter exists
- bridge client exists
- routing/fallback works in MVP form
- README.md exists and is useful
- implementation reflects the docs

At the end, output:
1. what you built
2. files created or changed
3. any doc ambiguities you resolved
4. what was intentionally deferred beyond MVP
